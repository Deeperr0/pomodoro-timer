import PropTypes from "prop-types";
import { FONT_CLASS_MAP } from "../../utils/fontClassMap";
export default function ModeButton({
  mode,
  setMode,
  modeName,
  backgroundColor,
  font,
  setStatus,
}) {
  return (
    <button
      type="button"
      aria-pressed={mode === modeName}
      onClick={() => {
        setMode(modeName);
        localStorage.setItem("mode", modeName);
        localStorage.setItem("status", "stopped");
        setStatus("stopped");
      }}
      className={`px-6 py-4 text-xs md:text-sm font-bold rounded-full ${
        FONT_CLASS_MAP[font] ?? "font-kumbh"
      } ${
        mode === modeName
          ? "text-darkBlue"
          : "text-customGray opacity-40 hover:opacity-100 transition-all duration-300"
      }`}
      style={{
        backgroundColor: mode === modeName ? backgroundColor : "transparent",
      }}
    >
      {modeName}
    </button>
  );
}
ModeButton.propTypes = {
  mode: PropTypes.string,
  setMode: PropTypes.func,
  modeName: PropTypes.string,
  backgroundColor: PropTypes.string,
  font: PropTypes.string,
  setStatus: PropTypes.func,
};
